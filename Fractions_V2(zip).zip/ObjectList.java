/*
This objectlist class serves the purpose of being a generic object list
*/
public class ObjectList {

    private int numElements = 0;
    private int arrayLength;
    private Object[] obj;

    // constructor which sets the size of the object
    ObjectList(int size) {
        arrayLength = size;
        obj = new Object[size];
    }

    // add method to add a new object to the list
    public void add(Object fraction) {
        obj[numElements++] = fraction;
    }

    // get method to return the object at the given index
    public Object get(int index) {
        return obj[index];
    }


    // toString method to print out the entire ObjectList
    @Override
    public String toString() {
        String retVal = "";
        for(int i = 0; i < numElements; i++) {
            retVal += obj[i];
            retVal += " ";
            
        }
        return retVal;
    }

    // method to check if list is almost out of space
    public boolean lengthCheck() {
        if (obj[arrayLength -1] != null) {
            return true;
        } else {
            return false;
        }

    }
    
    // gets numElements
    public int getNumElements() {
        return this.numElements;
    }
    
    // gets ArrayLength
    public int getArrayLength() {
        return this.arrayLength;
    }


}
